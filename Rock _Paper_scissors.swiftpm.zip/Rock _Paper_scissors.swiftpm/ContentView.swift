import SwiftUI

struct ContentView: View {
    var random:Int = Int.random(in: 0...4)
    @State var imageSelect:Int = 0
    @State var user = ""
    @State var com = ""
    @State var result = ""
    @State private var image: [Image] = []
    var body: some View {
       
        LinearGradient(gradient: Gradient(colors: [Color.red, Color.blue]), startPoint: .leading, endPoint: .trailing)
        VStack{
            Text("Rock, Paper, scissors")
                .font(.largeTitle)
                .background( LinearGradient(gradient: Gradient(colors: [Color.red, Color.blue]), startPoint: .leading, endPoint: .trailing))
        }
        HStack{
            Text("User")
                .font(.largeTitle)
             .background(LinearGradient(gradient: Gradient(colors: [Color.red, Color.blue]), startPoint: .leading, endPoint: .trailing))
             .padding()
            Text("\(result)")
                .background(LinearGradient(gradient: Gradient(colors: [Color.red, Color.blue]), startPoint: .leading, endPoint: .trailing))
            Text("Computer ")
                .font(.largeTitle)
                 .background(LinearGradient(gradient: Gradient(colors: [Color.red, Color.blue]), startPoint: .leading, endPoint: .trailing))
           
        }
        HStack{
            LinearGradient(gradient: Gradient(colors: [Color.red, Color.blue]), startPoint: .leading, endPoint: .trailing)
        }
        HStack{
            //User   
            if(imageSelect==1){
                Image("Paper")
                    .background(LinearGradient(gradient: Gradient(colors: [Color.red, Color.blue]), startPoint: .leading, endPoint: .trailing))
                // user = ""
            }else if (imageSelect==2) {
                Image("Punch")  
            }else if(imageSelect==3){
                Image("Scissor")
            }
            //Computer
            if(random == 1){
                Image("Paper")
            }else if (random == 2){
                Image("punch")
            }else if (random == 3){
                Image("Scissor")
            }
           
        }
        HStack {
            //User
           
            Image("Paper").onTapGesture {
                self.imageSelect = 1
                result = self.result(self.imageSelect, random)
            }
                       
            Image("Punch").onTapGesture {
                self.imageSelect = 2
                result = self.result(self.imageSelect, random)
            }
          LinearGradient(gradient: Gradient(colors: [Color.red, Color.blue]), startPoint: .leading, endPoint: .trailing)
            Image("Scissor").onTapGesture {
               
                self.imageSelect = 3
                result = self.result(self.imageSelect, random)
                    

            } 
                    }
        .background(LinearGradient(gradient: Gradient(colors: [Color.red, Color.blue]), startPoint: .leading, endPoint: .trailing))
    }

    func randomImage(_ im: Int) -> String{
        if (im == 1){
            return "Punch"
        }else if (im == 2) {
            return "Paper"
        }else if (im == 3){
            return "Scissor"
        }
        return "Rock"
    }
    func result(_ u: Int, _ c: Int) -> String {
        if (u == 1 && c == 2){
            return "😟"
        }
        if (u == 2 && c == 1){
            return "😄"
        }
        if (u == 2 && c == 3){
            return "😟"
        }
        if (u == 3 && c == 2){
            return "😄"
        }
        if( u == 3 && c == 1){
            return "😟"
        } 
        if( u == 1 && c == 3){
            return "😄"
        }
        if (u == 2 && c == 2){
            return "😑"
        }
        if (u == 1 && c == 1){
            return "😑"
        }
        if (u == 3 && c==3){
            return "😑"
        }
        return "😑"
    }
    
}



